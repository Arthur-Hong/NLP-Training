
# coding: utf-8

# In[147]:


import pandas as pd
from pprint import pprint
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_selection import chi2
from sklearn.feature_selection import SelectPercentile
import csv
from sklearn.metrics import classification_report 


# In[148]:


test_text=[]
test_label=[]
with open(r"C:\2017.9-2017.7\__MACOSX\baselineJson\PDTB_experiment_backup\20180802\BrwonClusterTest.csv", "r") as csvfile1:
    reader1 = csv.reader(csvfile1) # 读取csv文件，返回的是迭代类型
    for item1 in reader1:
        test_text.append(item1[0])
        test_label.append(item1[1])
# print(test_data)
# print(test_label)


# In[149]:


train_text=[]
train_label=[]
with open(r"C:\2017.9-2017.7\__MACOSX\baselineJson\PDTB_experiment_backup\20180802\BrwonClusterTrain.csv", "r") as csvfile2:
    reader2 = csv.reader(csvfile2) # 读取csv文件，返回的是迭代类型
    for item2 in reader2:
        train_text.append(item2[0])
        train_label.append(item2[1])


# In[150]:


# print(test_dict)
csvfile2.close()
csvfile1.close()


# In[151]:


vectorizer = CountVectorizer()


# In[152]:


import numpy as np


# In[153]:


s = SelectPercentile(chi2, percentile=80)


# In[154]:


train = vectorizer.fit_transform(train_text)


# In[155]:


train_data = s.fit_transform(train, train_label)


# In[156]:


print(train_data.shape)


# In[157]:


test_data=vectorizer.transform(test_text)


# In[158]:


test_data = s.transform(test_data)


# In[159]:


print(test_data.shape)


# In[160]:


clf = MultinomialNB()


# In[161]:


clf.fit(train_data, train_label)


# In[162]:


pred = clf.predict(test_data)


# In[163]:


print(classification_report(test_label, pred))

