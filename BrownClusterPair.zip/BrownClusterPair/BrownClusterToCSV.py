
# coding: utf-8

import json
from pprint import pprint
import string
import csv

with open(r"C:\2017.9-2017.7\__MACOSX\baselineJson\brown_cluster_3200.txt",'r') as BrownClusterF:
    BrownClusterf=BrownClusterF.readlines()
BrownClusterF.close()
#--------------------------------------------------------------------
#处理BrownCluster 变成字典形式
BrownClusterf=[word.strip('\n') for word in BrownClusterf]
# pprint(BrownClusterf)
for word in BrownClusterf:
    word=[word.split('\t')]
BCdict={}
for i in BrownClusterf:
    i=[i.split('\t')]
    BCdict[i[0][1]]=i[0][0]
# pprint(BCdict)
#--------------------------------------------------------------------

with open(r"C:\2017.9-2017.7\__MACOSX\baselineJson\PDTB_experiment_backup\imTrainCorenlp","r") as f1:
    data1 = json.load(f1)
f1.close()
with open(r"C:\2017.9-2017.7\__MACOSX\baselineJson\StopWord.txt","r") as f2:
    str = f2.read()
f2.close()
new_set = (str.split())
new_set.extend(string.punctuation)
new_dict={}
for key, value in data1.items():
    new_list1 = []
    new_list2 = []
    new_list = []
    for Tokens in value['Arg1']['Tokens']:
        if Tokens['Lemma'] not in new_set:
            if Tokens['Lemma'] in BCdict:
                new_pair1 = BCdict[Tokens['Lemma']]
            new_list1.append(new_pair1)
    for Tokens in value['Arg2']['Tokens']:
        if Tokens['Lemma'] not in new_set:
            if Tokens['Lemma'] in BCdict:
                new_pair2 = BCdict[Tokens['Lemma']]
            new_list2.append(new_pair2)
    for i in new_list1:
        for j in new_list2:
            new_list.append(i+'--'+j)
    str=' '
    feature=str.join(new_list)
    new_dict[feature]=value['Sense'].split('.')[0]

pprint(new_dict)
# pprint(new_list)
print('Total pairs %d' % len(new_dict))

# with open(r"C:\2017.9-2017.7\__MACOSX\baselineJson\PDTB_experiment_backup\Lemma_pair_nonstopTRAIN","w") as fw_json:
#     json.dump(new_list,fw_json)

csvFile = open(r"C:\2017.9-2017.7\__MACOSX\baselineJson\PDTB_experiment_backup\BrwonClusterTrain.csv",'w', newline='')
writer = csv.writer(csvFile)
for key in new_dict:
    writer.writerow([key, new_dict[key]])
csvFile.close()
