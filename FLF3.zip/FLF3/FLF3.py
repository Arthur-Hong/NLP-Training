
# coding: utf-8

# In[ ]:


import json
import string
import csv
import numpy as np
from pprint import pprint
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_selection import chi2
from sklearn.feature_selection import SelectPercentile
from sklearn.metrics import classification_report

with open(r"C:\Users\jxsfhxp\Desktop\PDTB_experiment_backup\imTrainCorenlp","r") as f1:
    data1 = json.load(f1)
with open(r"C:\Users\jxsfhxp\Desktop\PDTB_experiment_backup\imTestCorenlp","r") as F1:
    Data1 = json.load(F1)
f2 = open(r"C:\Users\jxsfhxp\Desktop\StopWord.txt","r")
str1 = f2.read()
f2.close()
StopWord_list = str1.split()
StopWord_list.extend(string.punctuation)

new_dict = {}
for key, value in data1.items():
    new_list1 = []
    new_list2 = []
    new_list = []
    m = 0
    n = 0
    for Tokens in value['Arg1']['Tokens']:
        if Tokens['Lemma'] not in StopWord_list:
            new_list1.append(Tokens['Lemma'])
            m = m+1
    del new_list1[2:m-2]
    for Tokens in value['Arg2']['Tokens']:
        if Tokens['Lemma'] not in StopWord_list:
            new_list2.append(Tokens['Lemma'])
            n = n+1
    del new_list2[2:n-2]
    for i in new_list1:
        for j in new_list2:
            new_list.append(i+'_FLF3Pair_'+j)
    new_str = ' '
    feature_str = new_str.join(new_list)
    new_dict[feature_str] = value['Sense'].split('.')[0]

csvFile = open(r"C:\Users\jxsfhxp\Desktop\train.csv",'w', newline='')
writer = csv.writer(csvFile)
for key in new_dict:
    writer.writerow([key, new_dict[key]])
csvFile.close()

New_dict = {}
for key, value in Data1.items():
    New_list1 = []
    New_list2 = []
    New_list = []
    m = 0
    n = 0
    for Tokens in value['Arg1']['Tokens']:
        if Tokens['Lemma'] not in StopWord_list:
            New_list1.append(Tokens['Lemma'])
            m = m+1
    del New_list1[2:m-2]
    for Tokens in value['Arg2']['Tokens']:
        if Tokens['Lemma'] not in StopWord_list:
            New_list2.append(Tokens['Lemma'])
            n = n+1
    del New_list2[2:n-2]
    for i in New_list1:
        for j in New_list2:
            New_list.append(i+'_FLF3Pair_'+j)
    New_str = ' '
    Feature_str = New_str.join(New_list)
    New_dict[Feature_str]= value['Sense'].split('.')[0]

CsvFile = open(r"C:\Users\jxsfhxp\Desktop\test.csv",'w', newline='')
Writer = csv.writer(CsvFile)
for key in New_dict:
    Writer.writerow([key, New_dict[key]])
CsvFile.close()

test_text=[]
test_label=[]
with open(r"C:\Users\jxsfhxp\Desktop\test.csv", "r") as csvfile1:
    reader1 = csv.reader(csvfile1)
    for item1 in reader1:
        test_text.append(item1[0])
        test_label.append(item1[1])
csvfile1.close()

train_text=[]
train_label=[]
with open(r"C:\Users\jxsfhxp\Desktop\train.csv", "r") as csvfile2:
    reader2 = csv.reader(csvfile2) 
    for item2 in reader2:
        train_text.append(item2[0])
        train_label.append(item2[1])
csvfile2.close()

vectorizer = CountVectorizer()
s = SelectPercentile(chi2, percentile=80)
train_data = vectorizer.fit_transform(train_text)
train_data = s.fit_transform(train_data, train_label)
test_data = vectorizer.transform(test_text)
test_data = s.transform(test_data)
clf = MultinomialNB()
clf.fit(train_data, train_label)
predict = clf.predict(test_data)
print(classification_report(test_label, predict))

