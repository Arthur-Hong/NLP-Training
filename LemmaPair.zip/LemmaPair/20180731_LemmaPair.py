
# coding: utf-8

# In[ ]:


import json
from pprint import pprint
with open(r"C:\Users\jxsfhxp\Desktop\PDTB_experiment_backup\imTestCorenlp","r") as f:
    data = json.load(f)
new_list = []
for key, value in data.items():
    new_list1 = []
    new_list2 = []
    for Tokens in value['Arg1']['Tokens']:
        new_list1.append(Tokens['Lemma'])
    for Tokens in value['Arg2']['Tokens']:
        new_list2.append(Tokens['Lemma'])
    for i in new_list1:
        for j in new_list2:
            new_list.append(i+'_LEMMAPAIR_'+j)
    pprint(new_list)


# In[ ]:




